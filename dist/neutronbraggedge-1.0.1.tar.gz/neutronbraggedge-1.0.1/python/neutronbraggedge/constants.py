mn = 1.674927471e-27  #kg - neutron mass
h = 6.62607004e-34 #J s - Planck constant